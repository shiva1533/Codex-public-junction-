create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text not null check (char_length(nickname) between 1 and 24),
  avatar text not null default '🐼',
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);

create table if not exists public.junctions (
  id text primary key check (id ~ '^[a-z0-9][a-z0-9-]{1,48}$'),
  name text not null,
  city text not null,
  category text not null,
  description text not null default '',
  is_public boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  room_id text not null references public.junctions(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  nickname text not null check (char_length(nickname) between 1 and 24),
  avatar text not null default '🐼',
  body text not null check (char_length(body) between 1 and 1000),
  reply_to uuid references public.messages(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists messages_room_created_idx on public.messages(room_id, created_at desc);

create table if not exists public.message_reactions (
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  emoji text not null check (emoji in ('❤️','😂','👍','🔥','👏')),
  created_at timestamptz not null default now(),
  primary key(message_id,user_id,emoji)
);

alter table public.profiles enable row level security;
alter table public.junctions enable row level security;
alter table public.messages enable row level security;
alter table public.message_reactions enable row level security;

-- Open public-room MVP policies. Add server-enforced bans, quotas and stricter membership checks before public launch.
create policy "profiles readable" on public.profiles for select to authenticated using (true);
create policy "users insert own profile" on public.profiles for insert to authenticated with check (auth.uid()=id);
create policy "users update own profile" on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);
create policy "public junctions readable" on public.junctions for select to anon, authenticated using (is_public=true);
create policy "messages readable by guests" on public.messages for select to authenticated using (true);
create policy "guests send own messages" on public.messages for insert to authenticated with check (auth.uid()=user_id);
create policy "reactions readable" on public.message_reactions for select to authenticated using (true);
create policy "guests add own reactions" on public.message_reactions for insert to authenticated with check (auth.uid()=user_id);
create policy "guests update own reactions" on public.message_reactions for update to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "guests remove own reactions" on public.message_reactions for delete to authenticated using (auth.uid()=user_id);

insert into public.junctions(id,name,city,category,description) values
('hyderabad','Hyderabad Junction','Hyderabad','City','Late-night chai, local stories and new faces.'),
('bangalore','Bangalore Junction','Bengaluru','City','Ideas, gigs, traffic stories and good conversations.'),
('chennai','Chennai Junction','Chennai','City','Music, movies and conversations by the coast.'),
('mumbai','Mumbai Junction','Mumbai','City','Big-city energy. Meet someone new.'),
('delhi','Delhi Junction','Delhi','City','Debates, food finds and everyday life.'),
('kolkata','Kolkata Junction','Kolkata','City','Books, art, football and adda.'),
('pune','Pune Junction','Pune','City','Students, creators and weekend plans.'),
('vizag','Vizag Junction','Visakhapatnam','City','Sea breeze and conversations.'),
('music-lounge','Music Lounge','Everywhere','Music','Share what you are listening to.'),
('study-room','Focus Club','Everywhere','Study','Quiet company and focused study sprints.'),
('tech-talk','Tech Talk','Everywhere','Technology','Build, learn and exchange ideas.'),
('random-talk','Random Talk','Everywhere','Random','No agenda. Just say hello.')
on conflict(id) do nothing;

-- Enable database change events for the chat table in Supabase Realtime.
alter publication supabase_realtime add table public.messages;
