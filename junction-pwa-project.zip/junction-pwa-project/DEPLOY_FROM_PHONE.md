# Deploy Junction from your phone

You can manage deployment from Chrome on Android. You do not need VS Code on your phone.

## What this package contains
React + TypeScript + Vite application source, a PWA manifest, app icons, service worker, Supabase integration points, Express API and LiveKit token endpoint. This is source code, not a public live website. A real multi-device app needs your own Supabase and LiveKit credentials and hosting deployment.

## 1. Create service projects
1. Create a Supabase project at https://supabase.com/dashboard.
2. In Supabase Authentication settings, enable Anonymous Sign-ins.
3. Open SQL Editor and run `supabase/migrations/0001_init.sql`.
4. Copy the project URL and anon/publishable key from Project Settings → API.
5. Create a LiveKit Cloud project at https://cloud.livekit.io and copy its WebSocket URL, API key and API secret.

## 2. Put the source in GitHub using your phone
1. Download and extract `junction-pwa-project.zip` on your phone.
2. In Chrome, open https://github.com/new and create a private repository named `junction`.
3. Upload the extracted project files and folders. If folder upload is unavailable on mobile, use Chrome's desktop-site mode or GitHub's mobile app.
4. Ensure repository root contains `package.json`, `vercel.json`, `apps/`, and `supabase/`.

## 3. Deploy the web app
1. Open https://vercel.com/new and import your GitHub repository.
2. Set Root Directory to `apps/web`.
3. Add `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, and `VITE_API_URL` as environment variables.
4. Deploy. Add the API URL and redeploy if it was not ready yet.

## 4. Deploy the API separately
Deploy `apps/api` as a Node service on Render or Railway. Use root directory `apps/api`, build command `npm install && npm run build`, and the package's start script. Set `PORT`, `WEB_ORIGIN`, `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `LIVEKIT_URL`, `LIVEKIT_API_KEY`, and `LIVEKIT_API_SECRET`.
Never put `LIVEKIT_API_SECRET` or Supabase service-role keys in frontend variables.

## 5. Install on Android
Open the deployed HTTPS URL in Chrome → menu ⋮ → Install app / Add to Home screen.

## Important
HTTPS hosting is required for service workers and installability. Supabase and LiveKit require your real credentials. Current public-room database policies and moderation are not hardened for unrestricted public launch. Test with two devices before inviting users.
