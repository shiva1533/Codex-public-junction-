# Junction — Phase 1 execution checklist

## Goal
Prove that two people on separate devices can enter the same public room, see each other, and exchange messages without refreshing.

## Before coding
- [ ] Confirm Node.js 20+ and npm versions.
- [ ] Create Supabase project and enable Anonymous Sign-Ins.
- [ ] Apply `supabase/migrations/0001_init.sql`.
- [ ] Configure web and API environment files using the examples.
- [ ] Confirm the API health endpoint responds.

## Implement
- [ ] Load room definitions from Supabase, not only the local `rooms` constant.
- [ ] Subscribe to Presence before tracking the current user; handle `SUBSCRIBED`, `CHANNEL_ERROR`, `TIMED_OUT`, reconnect and cleanup.
- [ ] Keep one room channel per active room and always remove it on leave/unmount.
- [ ] Handle the race between initial message fetch and realtime INSERT events without duplicates.
- [ ] Add pagination for older messages.
- [ ] Subscribe to reaction changes and display per-emoji counts plus the current user's selection.
- [ ] Add typing presence with a short expiry; do not persist typing events.
- [ ] Add server/database-enforced slow mode and message quotas. Client-side checks alone do not count.
- [ ] Add report and block flows backed by database records and moderation review.
- [ ] Add reconnect/offline/empty/loading/error states.
- [ ] Ensure chat works without requesting microphone permission.

## Security review
- [ ] Review every RLS policy with an anonymous-authenticated user.
- [ ] Ensure guests can only mutate their own profile and reactions.
- [ ] Ensure message authorship comes from `auth.uid()` and cannot be spoofed.
- [ ] Validate nickname, room ID, message body, reply target and emoji on trusted boundaries.
- [ ] Add retention/cleanup policy for temporary profiles and messages.
- [ ] Do not expose service-role or LiveKit secrets in Vite variables.

## Manual acceptance test
1. Open the app in two independent browsers (or one normal and one private window).
2. Give each browser a different nickname and avatar.
3. Join Hyderabad Junction in both.
4. Confirm both browsers show two participants without refreshing.
5. Send a message in browser A; confirm it appears in browser B.
6. Reply and react from browser B; confirm browser A sees the update.
7. Close browser B; confirm its presence disappears after disconnect/timeout.
8. Repeat on an Android phone browser and desktop browser.
9. Confirm no microphone permission prompt appears during text-only use.

## Exit criteria
Phase 1 is not complete until `npm run build` succeeds, automated tests pass, and the manual acceptance test above succeeds. Do not mark voice, moderation, or production readiness complete based on UI alone.
