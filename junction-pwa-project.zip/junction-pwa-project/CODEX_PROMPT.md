# Codex implementation brief — Junction

You are the senior engineer continuing this repository. Read README.md and PHASE1_TASKS.md first, then inspect the existing code before changing it. Do not replace working pieces with mock UI.

## Objective
Turn this starter into a production-grade public social hangout platform. Preserve the dark, premium, responsive visual direction already implemented. Prioritize correctness, safety, accessibility, and mobile browser behavior over decorative features.

## Non-negotiable engineering rules
- TypeScript strict mode. Validate all API inputs with a schema library (Zod recommended).
- Never expose Supabase service-role or LiveKit API secrets in the browser.
- No microphone capture until the user explicitly presses Join Voice and grants browser permission.
- Support listen-only mode; publish audio only after explicit opt-in.
- Presence is ephemeral. Handle tab close, reconnect, stale presence, and duplicate sessions.
- Use server-authoritative room membership, bans, rate limits, and moderation. Do not trust nickname, role, room counts, or client-sent events.
- Add tests for auth, authorization, rate limits, message validation, and token issuance.
- Do not implement music redistribution. Use licensed/provider-authorized playback only.

## Required work, in order

### Milestone 1 — make Phase 1 reliable
1. Fix any TypeScript/build/runtime errors.
2. Replace static room counts with Supabase Realtime Presence counts.
3. Make chat realtime robust: optimistic UI, duplicate-event protection, pagination, retry state, typing presence, replies, and reaction counts/state.
4. Add profile creation/update constraints and safe nickname normalization.
5. Add slow mode and per-user/per-room server-enforced message limits. Use a trusted server path or Postgres function; do not rely only on client checks.
6. Add block/report UX and a moderation queue schema. Blocking should hide the blocked user's content locally and prevent direct random matching.
7. Implement proper loading, empty, error, offline, reconnect, and permission-denied states.

### Milestone 2 — voice
1. Integrate LiveKit React components or a well-tested custom room hook.
2. Add listen-only join, explicit publish, mute/unmute, leave voice, active-speaker indicators, participant tiles, hand raise via reliable data messages, and reconnect handling.
3. Configure server-issued tokens with short TTL, room membership checks, participant metadata, publish permissions, and room capacity limits.
4. Add LiveKit webhooks for authoritative participant lifecycle updates and cleanup.
5. Test Android Chrome and iOS Safari microphone permission/device switching.

### Milestone 3 — safety and scale
1. Add moderator roles, room rules, report categories, user blocking, timeouts, bans, audit logs, and admin review UI.
2. Add retention/cleanup jobs for anonymous profiles and old chat data; document retention clearly.
3. Add observability, structured logs, error tracking, metrics, backups, health checks, and load tests.
4. Add abuse controls: CAPTCHA or risk-based friction when needed, message quotas, duplicate spam detection, link controls, and room creation limits.

### Milestone 4 — extras
Only after core usage and moderation are stable: games, music sessions using licensed playback, virtual gifts, richer discovery, and user-created rooms.

## Acceptance criteria
- Two different browsers can enter the same room with temporary identities and see each other appear/disappear without refresh.
- Messages, replies, and reactions appear across browsers in near real time.
- A guest can chat without microphone permission.
- Voice is multi-user through LiveKit SFU; microphone is never enabled automatically.
- Expired/invalid tokens cannot join rooms; users cannot mint tokens for private, banned, or nonexistent rooms.
- Mobile layouts have no horizontal overflow and controls remain reachable above the browser safe area.
- `npm run build` succeeds and automated tests pass.

Start immediately with Milestone 1. Do not stop after summarizing the plan or merely proposing code. Implement the changes in this repository, install dependencies, run the build and tests, and report exact command output. If external credentials are missing, finish all credential-independent work and give the precise remaining setup steps. Before each later milestone, summarize the plan, then implement and run tests. Do not claim a feature is complete unless it works end-to-end.
