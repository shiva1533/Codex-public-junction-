import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { createClient } from '@supabase/supabase-js';
import { AccessToken } from 'livekit-server-sdk';

const app = express();
const port = Number(process.env.PORT ?? 4000);
const required = ['SUPABASE_URL','SUPABASE_ANON_KEY','LIVEKIT_URL','LIVEKIT_API_KEY','LIVEKIT_API_SECRET'] as const;
for (const key of required) if (!process.env[key]) console.warn(`Missing environment variable: ${key}`);
const supabase = createClient(process.env.SUPABASE_URL ?? '', process.env.SUPABASE_ANON_KEY ?? '', { auth: { persistSession:false } });
app.use(helmet());
app.use(cors({ origin: process.env.WEB_ORIGIN ?? 'http://localhost:5173' }));
app.use(express.json({ limit:'16kb' }));
app.use('/api', rateLimit({ windowMs:60_000, limit:30, standardHeaders:true, legacyHeaders:false }));
app.get('/health', (_req,res)=>res.json({ok:true,service:'junction-api'}));
app.post('/api/livekit/token', async (req,res)=>{
  try {
    const header=req.header('authorization') ?? '';
    const accessToken=header.startsWith('Bearer ')?header.slice(7):'';
    if(!accessToken) return res.status(401).json({error:'Missing bearer token'});
    const {data:{user},error}=await supabase.auth.getUser(accessToken);
    if(error || !user) return res.status(401).json({error:'Invalid session'});
    const roomName=typeof req.body?.roomName==='string'?req.body.roomName:'';
    if(!/^[a-z0-9][a-z0-9-]{1,48}$/.test(roomName)) return res.status(400).json({error:'Invalid room name'});
    const {data:room,error:roomError}=await supabase.from('junctions').select('id').eq('id',roomName).eq('is_public',true).maybeSingle();
    if(roomError || !room) return res.status(404).json({error:'Junction not found'});
    const identity=user.id;
    const token=new AccessToken(process.env.LIVEKIT_API_KEY!,process.env.LIVEKIT_API_SECRET!,{identity,ttl:'10m',name:typeof req.body.nickname==='string'?req.body.nickname.slice(0,24):'Junction guest'});
    token.addGrant({roomJoin:true,room:roomName,canPublish:true,canSubscribe:true,canPublishData:true});
    return res.json({url:process.env.LIVEKIT_URL,token:await token.toJwt()});
  } catch(e) { console.error('LiveKit token error',e); return res.status(500).json({error:'Could not create voice session'}); }
});
app.listen(port,()=>console.log(`Junction API listening on ${port}`));
