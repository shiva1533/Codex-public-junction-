import { useEffect, useMemo, useState } from 'react';
import { ArrowUpRight, AudioLines, Compass, Hash, Headphones, MessageCircle, Mic, MicOff, Plus, Search, Shuffle, Users, Volume2, X } from 'lucide-react';
import { motion } from 'framer-motion';
import { API_URL, ensureTemporaryIdentity, supabase } from './lib';

type Junction = { id: string; name: string; city: string; category: string; description: string; gradient: string; online: number };
type ChatMessage = { id: string; user_id: string; nickname: string; avatar: string; body: string; created_at: string; reply_to: string | null };
const rooms: Junction[] = [
  { id:'hyderabad', name:'Hyderabad Junction', city:'Hyderabad', category:'City', description:'Late-night chai, local stories and new faces.', gradient:'sunset', online:0 },
  { id:'bangalore', name:'Bangalore Junction', city:'Bengaluru', category:'City', description:'Ideas, gigs, traffic stories and good conversations.', gradient:'mint', online:0 },
  { id:'chennai', name:'Chennai Junction', city:'Chennai', category:'City', description:'Music, movies and conversations by the coast.', gradient:'ocean', online:0 },
  { id:'mumbai', name:'Mumbai Junction', city:'Mumbai', category:'City', description:'Big-city energy. Meet someone new.', gradient:'rose', online:0 },
  { id:'delhi', name:'Delhi Junction', city:'Delhi', category:'City', description:'Debates, food finds and everyday life.', gradient:'violet', online:0 },
  { id:'kolkata', name:'Kolkata Junction', city:'Kolkata', category:'City', description:'Books, art, football and adda.', gradient:'amber', online:0 },
  { id:'pune', name:'Pune Junction', city:'Pune', category:'City', description:'Students, creators and weekend plans.', gradient:'blue', online:0 },
  { id:'vizag', name:'Vizag Junction', city:'Visakhapatnam', category:'City', description:'Sea breeze and conversations.', gradient:'teal', online:0 },
  { id:'music-lounge', name:'Music Lounge', city:'Everywhere', category:'Music', description:'Share what you are listening to.', gradient:'rose', online:0 },
  { id:'study-room', name:'Focus Club', city:'Everywhere', category:'Study', description:'Quiet company and focused study sprints.', gradient:'blue', online:0 },
  { id:'tech-talk', name:'Tech Talk', city:'Everywhere', category:'Technology', description:'Build, learn and exchange ideas.', gradient:'mint', online:0 },
  { id:'random-talk', name:'Random Talk', city:'Everywhere', category:'Random', description:'No agenda. Just say hello.', gradient:'violet', online:0 },
];
const avatars = ['🐼','🦊','🐯','🐸','🐻','🐙','🦉','🐨','🦄','🐧'];
const randomName = () => ['Curious','Happy','Silent','Cosmic','Brave','Mellow'][Math.floor(Math.random()*6)] + ' ' + ['Panda','Fox','Tiger','Explorer','Otter','Comet'][Math.floor(Math.random()*6)];

export default function App() {
  const [active, setActive] = useState<Junction | null>(null);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [nickname, setNickname] = useState(randomName());
  const [avatar, setAvatar] = useState(avatars[Math.floor(Math.random()*avatars.length)]);
  const [showIdentity, setShowIdentity] = useState<Junction | null>(null);
  const [userId, setUserId] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState('');
  const [people, setPeople] = useState<{id:string;nickname:string;avatar:string;voice:boolean}[]>([]);
  const [status, setStatus] = useState('Connecting');
  const [error, setError] = useState('');
  const [voice, setVoice] = useState(false);
  const [muted, setMuted] = useState(true);
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null);
  const [mobilePeople, setMobilePeople] = useState(false);
  const [chatMuted, setChatMuted] = useState(false);
  const [installEvent, setInstallEvent] = useState<any>(null);
  const [installDismissed, setInstallDismissed] = useState(false);
  const filtered = useMemo(() => rooms.filter(r => (category==='All' || r.category===category) && `${r.name} ${r.city} ${r.category}`.toLowerCase().includes(search.toLowerCase())), [search, category]);

  useEffect(() => {
    const onInstall = (event: Event) => { event.preventDefault(); setInstallEvent(event); };
    window.addEventListener('beforeinstallprompt', onInstall);
    return () => window.removeEventListener('beforeinstallprompt', onInstall);
  }, []);
  async function installApp() {
    if (!installEvent) return;
    await installEvent.prompt();
    setInstallEvent(null);
  }

  useEffect(() => { ensureTemporaryIdentity().then(s => { setUserId(s.user.id); setStatus('Connected'); }).catch(e => { setStatus('Setup needed'); setError(e.message); }); }, []);

  async function enterRoom(room: Junction) { setNickname(nickname.trim() || randomName()); setShowIdentity(room); }
  async function confirmJoin() {
    if (!showIdentity || !supabase || !userId) return;
    const room = showIdentity; setActive(room); setShowIdentity(null); setError('');
    const { error: profileError } = await supabase.from('profiles').upsert({ id:userId, nickname:nickname.trim().slice(0,24), avatar });
    if (profileError) setError(profileError.message);
    const { data, error: msgError } = await supabase.from('messages').select('*').eq('room_id',room.id).order('created_at',{ascending:true}).limit(80);
    if (msgError) setError(msgError.message); else setMessages((data ?? []) as ChatMessage[]);
    const channel = supabase.channel(`room:${room.id}`, { config:{ presence:{ key:userId } } });
    channel.on('presence',{event:'sync'},()=>{
      const state=channel.presenceState();
      setPeople(Object.entries(state).flatMap(([id, metas]) => (metas as any[]).map(m=>({id,nickname:m.nickname,avatar:m.avatar,voice:!!m.voice}))));
    });
    channel.subscribe(async s=>{ if(s==='SUBSCRIBED') await channel.track({nickname:nickname.trim(),avatar,voice:false,joined_at:new Date().toISOString()}); });
    channel.on('postgres_changes',{event:'INSERT',schema:'public',table:'messages',filter:`room_id=eq.${room.id}`},payload=>setMessages(prev=>prev.some(m=>m.id===payload.new.id)?prev:[...prev,payload.new as ChatMessage]));
    (window as any).__junctionChannel = channel;
  }
  async function leaveRoom() {
    if ((window as any).__junctionChannel) { await supabase?.removeChannel((window as any).__junctionChannel); (window as any).__junctionChannel=null; }
    setActive(null); setMessages([]); setPeople([]); setVoice(false); setMuted(true); setReplyTo(null);
  }
  async function sendMessage() {
    const body=draft.trim(); if(!body || !active || !supabase || !userId) return;
    if(body.length>1000){setError('Messages are limited to 1,000 characters.');return;}
    const {error:e}=await supabase.from('messages').insert({room_id:active.id,user_id:userId,nickname:nickname.trim(),avatar,body,reply_to:replyTo?.id??null});
    if(e) setError(e.message); else {setDraft('');setReplyTo(null);}
  }
  async function toggleVoice() {
    if(!active) return;
    if(!voice){
      try {
        const session=await supabase?.auth.getSession(); const token=session?.data.session?.access_token;
        const response=await fetch(`${API_URL}/api/livekit/token`,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({roomName:active.id})});
        const payload=await response.json(); if(!response.ok) throw new Error(payload.error||'Voice token request failed');
        const {Room}=await import('livekit-client');
        const liveRoom=new Room(); await liveRoom.connect(payload.url,payload.token);
        // Join listen-only. Microphone capture starts only after the separate Unmute action.
        (window as any).__junctionLiveRoom=liveRoom; setVoice(true); setMuted(true);
        const channel=(window as any).__junctionChannel; if(channel) await channel.track({nickname,avatar,voice:true,joined_at:new Date().toISOString()});
      } catch(e:any){setError(e.message||'Could not join voice.');}
    } else {
      await (window as any).__junctionLiveRoom?.disconnect(); (window as any).__junctionLiveRoom=null; setVoice(false); setMuted(true);
      const channel=(window as any).__junctionChannel; if(channel) await channel.track({nickname,avatar,voice:false,joined_at:new Date().toISOString()});
    }
  }
  async function toggleMute(){ const room=(window as any).__junctionLiveRoom; if(!room) return; try { await room.localParticipant.setMicrophoneEnabled(muted); setMuted(!muted); } catch(e:any) { setError(e.message || 'Microphone permission was not granted.'); } }

  return <div className="app-shell">
    {installEvent && !installDismissed && !active && <div className="install-banner">
      <div><b>Take Junction with you</b><span>Install it on your phone for an app-like experience.</span></div>
      <button onClick={installApp}>Install</button>
      <button className="install-dismiss" aria-label="Dismiss install prompt" onClick={()=>setInstallDismissed(true)}>×</button>
    </div>}
    <header className="topbar"><a className="brand" href="#"><span className="brand-mark"><AudioLines size={21}/></span><span>junction<span className="brand-dot">.</span></span></a><div className="top-center"><span className="live-dot"/> {people.length || '—'} people hanging out</div><div className="top-right"><span className="connection">{status}</span><div className="mini-avatar">{avatar}</div></div></header>
    {!active ? <main className="discovery"><section className="hero"><div className="eyebrow"><span className="live-dot"/> THE INTERNET'S PUBLIC LIVING ROOM</div><h1>Good conversations<br/><em>happen by chance.</em></h1><p>Drop into a city. Meet someone new. Stay for the conversation.</p><div className="search-wrap"><Search size={19}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search cities, interests or Junctions..."/><kbd>⌘ K</kbd></div><div className="hero-actions"><button className="primary" onClick={()=>enterRoom(filtered[Math.floor(Math.random()*filtered.length)]||rooms[0])}><Shuffle size={17}/> Surprise me</button><span className="hero-note">No account. No awkward introductions.</span></div></section>
      <section className="section-head"><div><div className="eyebrow muted">FIND YOUR PEOPLE</div><h2>Explore Junctions</h2></div><span className="section-count">{filtered.length} PLACES TO DROP IN</span></section>
      <nav className="filters">{['All','City','Music','Gaming','Study','Technology','Friendship','Random'].map(c=><button key={c} className={category===c?'filter active':'filter'} onClick={()=>setCategory(c)}>{c}</button>)}</nav>
      <div className="room-grid">{filtered.map((r,i)=><motion.article key={r.id} className="room-card" initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} transition={{delay:i*.035}}><div className={`room-art ${r.gradient}`}><span className="art-orb orb-one"/><span className="art-orb orb-two"/><span className="art-city">{r.city==='Everywhere'?'✳':r.city.slice(0,2).toUpperCase()}</span><span className="art-category">{r.category}</span></div><div className="room-info"><div className="room-title-row"><h3>{r.name}</h3><span className="room-live"><i/> LIVE</span></div><p>{r.description}</p><div className="room-bottom"><span><Users size={15}/> Live room</span><button onClick={()=>enterRoom(r)}>Join Junction <ArrowUpRight size={15}/></button></div></div></motion.article>)}</div>
      <footer className="footer"><span>© 2026 Junction</span><span>Be curious. Be kind. Keep it human.</span><span>Public rooms · Temporary identities</span></footer>
    </main> : <main className="room-layout"><aside className="left-rail"><button className="back-button" onClick={leaveRoom}><X size={16}/> Leave room</button><div className="rail-label">YOUR SPACE</div><div className="rail-room"><span className={`rail-icon ${active.gradient}`}>✳</span><div><b>{active.name}</b><small>{active.category} Junction</small></div></div><div className="rail-label">DISCOVER MORE</div>{rooms.filter(r=>r.id!==active.id).slice(0,6).map(r=><button className="rail-link" key={r.id} onClick={()=>{leaveRoom();enterRoom(r)}}><Hash size={14}/>{r.name}</button>)}</aside>
      <section className="chat-column"><div className="room-heading"><div><div className="eyebrow muted">YOU ARE NOW IN</div><h1>{active.name}</h1><p>{active.description}</p></div><button className="people-toggle" onClick={()=>setMobilePeople(!mobilePeople)}><Users size={17}/>{people.length}</button></div>
        <div className="voice-stage"><div className="voice-stage-head"><span><AudioLines size={16}/> VOICE LOUNGE</span><span className="stage-count">{people.filter(p=>p.voice).length} in voice</span></div><div className="voice-people">{people.filter(p=>p.voice).length===0?<div className="voice-empty"><div className="sound-rings"><Headphones size={25}/></div><b>The room is warming up</b><span>Join voice when you're ready. Your mic stays off until you choose.</span></div>:people.filter(p=>p.voice).map(p=><div className="voice-person" key={p.id}><div className="person-avatar speaking">{p.avatar}</div><b>{p.nickname}{p.id===userId?' (you)':''}</b><span className="speaking-bars"><i/><i/><i/><i/></span></div>)}</div></div>
        <div className="chat-heading"><div><MessageCircle size={17}/><b>Room conversation</b></div><button className="quiet-button" onClick={()=>setChatMuted(!chatMuted)}>{chatMuted?'Unmute notifications':'Mute notifications'}</button></div>
        <div className="messages">{messages.length===0?<div className="welcome-chat"><div className="welcome-icon">✳</div><h3>You're at the start of something.</h3><p>Say hello. Someone might be glad you did.</p></div>:messages.map(m=><div className="message" key={m.id}><div className="message-avatar">{m.avatar}</div><div className="message-content">{m.reply_to&&<div className="reply-context">↳ Replying to an earlier message</div>}<div className="message-meta"><b>{m.nickname}{m.user_id===userId?' · you':''}</b><time>{new Date(m.created_at).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</time></div><p>{m.body}</p><div className="message-actions"><button onClick={()=>setReplyTo(m)}>Reply</button>{['❤️','😂','👍','🔥','👏'].map(e=><button key={e} onClick={()=>supabase?.from('message_reactions').upsert({message_id:m.id,user_id:userId,emoji:e})}>{e}</button>)}</div></div></div>)}</div>
        <div className="composer-wrap">{replyTo&&<div className="replying">Replying to <b>{replyTo.nickname}</b>: {replyTo.body.slice(0,60)}<button onClick={()=>setReplyTo(null)}><X size={14}/></button></div>}<div className="composer"><button className="emoji-button" onClick={()=>setDraft(d=>d+' 😊')}>☺</button><input value={draft} onChange={e=>setDraft(e.target.value)} onKeyDown={e=>e.key==='Enter'&&sendMessage()} placeholder="Message the Junction..." maxLength={1000}/><button className="send-button" onClick={sendMessage}>Send <ArrowUpRight size={15}/></button></div><div className="composer-hint">Be respectful. This is a public room.</div></div>
      </section><aside className={`right-rail ${mobilePeople?'show-mobile':''}`}><div className="participants-head"><div><b>People here</b><span>{people.length} online</span></div><button className="close-people" onClick={()=>setMobilePeople(false)}><X size={17}/></button></div><div className="participant-list">{people.map(p=><div className="participant" key={p.id}><span className="participant-avatar">{p.avatar}</span><span className="participant-name">{p.nickname}{p.id===userId?' (you)':''}</span>{p.voice&&<AudioLines size={15} className="voice-icon"/>}</div>)}</div><div className="room-guidelines"><b>A little room etiquette</b><p>Make space for others. No harassment, spam or sharing private information.</p><button onClick={()=>setError('Report flow is a Phase 3 item; moderation endpoint must be added before public launch.')}>Report a problem</button></div></aside>
      <div className="voice-dock"><div className="dock-status"><span className={voice?'live-dot':'idle-dot'}/><span>{voice?'In voice':'Listening to the room'}</span></div><div className="dock-controls"><button className={voice?'control active':'control'} onClick={toggleVoice}>{voice?<Headphones size={18}/>:<Headphones size={18}/>}<span>{voice?'Leave voice':'Join voice'}</span></button><button className="control" disabled={!voice} onClick={toggleMute}>{muted?<MicOff size={18}/>:<Mic size={18}/>}<span>{muted?'Enable mic':'Mute'}</span></button><button className="control" onClick={()=>setError('Raise-hand signaling is planned for the voice phase.')}>✋<span>Raise hand</span></button></div><button className="dock-leave" onClick={leaveRoom}>Leave Junction</button></div>
      </main>}
    {showIdentity&&<div className="modal-backdrop"><div className="identity-modal"><button className="modal-close" onClick={()=>setShowIdentity(null)}><X size={18}/></button><div className="eyebrow muted">ONE QUICK THING</div><h2>How should we call you?</h2><p>Pick a temporary name. No account or personal details needed.</p><label>YOUR NICKNAME</label><input value={nickname} maxLength={24} onChange={e=>setNickname(e.target.value)}/><label>CHOOSE AN AVATAR</label><div className="avatar-picker">{avatars.map(a=><button key={a} className={avatar===a?'chosen':''} onClick={()=>setAvatar(a)}>{a}</button>)}</div><button className="primary join-confirm" disabled={!userId||!nickname.trim()} onClick={confirmJoin}>Enter {showIdentity.name} <ArrowUpRight size={17}/></button><small>Your identity is temporary and visible to people in this room.</small></div></div>}
    {error&&<div className="toast"><span>{error}</span><button onClick={()=>setError('')}><X size={15}/></button></div>}
  </div>;
}
