# Junction — real-time social hangout starter

An early implementation starter for public city/topic rooms. It contains initial UI and service integrations, but has not yet passed a complete build or end-to-end acceptance test. Do not treat it as production-ready.

## Architecture

- **Web:** React + TypeScript + Vite. Supabase JS handles anonymous sessions, Postgres-backed chat, and Realtime Presence.
- **API:** Node.js + Express. Issues short-lived LiveKit access tokens after verifying the caller's Supabase access token.
- **Data:** Supabase Postgres. RLS protects room and message data; temporary users are Supabase anonymous-auth users.
- **Voice:** LiveKit SFU. The browser only receives a room-scoped, short-lived token. Never expose the LiveKit API secret in the browser.
- **Deploy:** Web on Vercel; API on Render/Fly.io/Railway; Supabase hosted; LiveKit Cloud or self-hosted LiveKit.

## Start locally

1. Install Node.js 20+ and create a Supabase project.
2. Copy `.env.example` to `apps/web/.env` and `apps/api/.env`; fill in the values.
3. In Supabase SQL Editor, run `supabase/migrations/0001_init.sql`.
4. In Supabase Auth settings, enable **Anonymous sign-ins**.
5. Install and run:

   ```bash
   npm install
   npm run dev
   ```

6. Open the Vite URL shown in the terminal. API defaults to `http://localhost:4000`.

## Environment variables

### `apps/web/.env`
- `VITE_SUPABASE_URL` — Supabase project URL
- `VITE_SUPABASE_ANON_KEY` — Supabase anon/publishable key (safe for browser when RLS is correct)
- `VITE_API_URL` — API origin, e.g. `http://localhost:4000`

### `apps/api/.env`
- `PORT` — API port (default 4000)
- `WEB_ORIGIN` — allowed browser origin
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY` — used to verify user access tokens
- `LIVEKIT_URL` — LiveKit websocket URL, e.g. `wss://your-project.livekit.cloud`
- `LIVEKIT_API_KEY`
- `LIVEKIT_API_SECRET` — server-only secret

## Database model

- `profiles`: temporary nickname/avatar keyed to Supabase anonymous user ID.
- `junctions`: public city/topic rooms and metadata.
- `messages`: room messages, optional reply target, timestamps.
- `message_reactions`: one reaction per user/message/emoji.

Presence is ephemeral and lives in Supabase Realtime Presence, not a durable `online=true` database field. LiveKit owns voice transport and speaker/mute state. Never treat a browser-supplied participant count as authoritative.

## API

- `GET /health` — liveness check.
- `POST /api/livekit/token` — verifies Supabase bearer token, checks room exists, returns a short-lived LiveKit token. JSON body: `{ "roomName": "hyderabad" }`.

## MVP gaps before public launch

1. Add server-side nickname/profile creation and edit validation, room membership authorization, bans, moderator roles, report review queue, and audit logs.
2. Add message rate limits per authenticated user and room; current API limiter is only a coarse IP-level baseline.
3. Add retention cleanup for anonymous profiles/messages according to a published policy; do not rely on browser disconnect events.
4. Configure Supabase Realtime channel authorization and production RLS review. Current public-room read/write policies are intentionally permissive for an open public MVP and need anti-abuse hardening before launch.
5. Add LiveKit webhooks for participant join/leave and server-side room limits. Do not use client events as billing or safety truth.
6. Add consent UX, report/block flows, age/safety policy, moderation dashboard, observability, backups, load tests, and privacy review.
7. Music must use licensed streams or user-owned audio; synchronize metadata/playback intent, not redistributed copyrighted tracks.

## Phase 1 execution checklist

See [`PHASE1_TASKS.md`](./PHASE1_TASKS.md) for the implementation and two-browser acceptance checklist.

## Suggested build order

1. Ship city discovery, anonymous identity, Presence, chat, replies, reactions.
2. Ship LiveKit voice with explicit microphone opt-in and listen-only entry.
3. Add moderation, limits, and operational tooling before growth.
4. Add games/music/gifts after core retention and safety are proven.

## Mobile / PWA

The web app includes a PWA manifest, app icons, an app-shell service worker, Android install prompt, and mobile safe-area styling. After deploying to HTTPS, open the URL in Chrome on Android and choose **Install app** or **Add to Home screen**. See [`DEPLOY_FROM_PHONE.md`](./DEPLOY_FROM_PHONE.md).

PWA installation does not provide backend services by itself: Supabase and LiveKit still need your credentials and deployment.
